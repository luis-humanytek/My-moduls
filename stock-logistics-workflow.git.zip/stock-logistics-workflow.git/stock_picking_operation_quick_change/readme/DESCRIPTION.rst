This module extends standard WMS to allow change destination location for all
picking operations.
