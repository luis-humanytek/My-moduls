To use this module, you need to:

* Go to a Delivery Order.
* Click on the button Send by Email.
* And finally click on the button Send.
