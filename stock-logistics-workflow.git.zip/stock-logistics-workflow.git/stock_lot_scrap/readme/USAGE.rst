* Go to *Inventory > Master Data > Lots/Serial Numbers*, and enter in
  view form mode.
* Click button *Scrap*
