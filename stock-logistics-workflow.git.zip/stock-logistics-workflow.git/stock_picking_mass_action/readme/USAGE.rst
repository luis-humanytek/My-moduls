After selecting several pickings in tree view there are options for:
* Mark as Todo
* Check Availability
* Force Availability
* Transfer

Select additional options in the wizard if needed, after "Apply" the actions
will be applied to all selected pickings
