* Guewen Baconnier <guewen.baconnier@camptocamp.com>
* Sylvain Le Gal (https://twitter.com/legalsylvain)
* `Tecnativa <https://www.tecnativa.com>`_:
  * Vicent Cubells
