This module extends the functionality of stock: in a picking out the user
can only select the lots available in the origin location.
