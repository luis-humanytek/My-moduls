To use this module you need to:

#. Go to a *Inventory > Dashboard > Delivery Orders*.
#. Create a picking with more than one line.
#. Confirm the picking.
#. Click to Scrap all button.

Yo can scrap all product and quantities in one step including lots, owners and
packages.
