This module adds a button in *Production Lot/Serial Number* view form to
*Scrap* all quants contained.
