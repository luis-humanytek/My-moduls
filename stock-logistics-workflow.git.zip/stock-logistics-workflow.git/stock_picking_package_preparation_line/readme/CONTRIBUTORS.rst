* Francesco Apruzzese <f.apruzzese@apuliasoftware.it>
* Lorenzo Battistini <lorenzo.battistini@agilebg.com>
* Alessio Gerace <alessio.gerace@agilebg.com>
