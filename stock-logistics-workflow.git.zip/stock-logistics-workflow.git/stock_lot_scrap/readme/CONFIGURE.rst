* Go to *Inventory > Configuration > Settings > Traceability*.
* Enable *Lots & Serial Numbers*.
