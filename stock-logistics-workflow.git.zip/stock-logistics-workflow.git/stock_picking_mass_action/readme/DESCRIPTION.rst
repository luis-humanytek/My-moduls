Facilities to check the availability of stock picking list:

* A wizard which allows on multiple stock pickings at a time to:

  * Confirm draft picking;
  * check availability of picking;
  * force availability of picking;
  * transfer picking;

* A scheduled action to check availability of all the stock picking.
  It is not active by default.

  This may be necessary for those who want to check the availability
  more often than running the procurement scheduler.
