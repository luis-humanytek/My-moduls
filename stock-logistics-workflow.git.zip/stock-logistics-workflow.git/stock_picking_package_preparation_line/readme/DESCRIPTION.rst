This module adds a new class on **Package Preparation** to manage details
related with stock move or not
