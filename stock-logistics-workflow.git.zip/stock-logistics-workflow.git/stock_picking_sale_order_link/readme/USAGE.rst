To use this module, you need to:

#. Go to *Sales > Products* and create one of type "Stockable".
#. Go to *Sales > Sales Orders* and create one and confirm.
#. Go to the picking generated clicking in delivery smartbutton.
#. In the picking appears a new smartbutton to navigate to the sales order
   called *Sales Order*.
