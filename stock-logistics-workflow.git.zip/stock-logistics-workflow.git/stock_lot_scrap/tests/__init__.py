from . import test_stock_lot_scrap
