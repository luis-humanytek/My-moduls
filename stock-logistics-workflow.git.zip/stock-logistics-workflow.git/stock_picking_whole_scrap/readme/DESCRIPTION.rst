This module extends the functionality of stock module to allow scrap
quantities quickly from a picking.
