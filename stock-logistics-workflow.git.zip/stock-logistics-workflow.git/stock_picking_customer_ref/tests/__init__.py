# -*- coding: utf-8 -*-

from . import test_stock_picking_customer_ref
