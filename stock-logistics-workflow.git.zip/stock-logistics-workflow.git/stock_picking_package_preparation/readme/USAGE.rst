To use this module, you need to:

 * Go to Inventory > Operations > Package Preparations

From there, you can create a new preparation.
Choose a partner then the selection of pickings you want in the package.
You can choose a packaging, it will be set on the generated package.

When you click on **Put in pack**, it generates the pack, which is not
finalized yet (no quants), but you can verify the operations in the
**Operations** tab.
Eventually, when you click on **Done**, all the pickings will be
transferred and the package operations will be performed.
