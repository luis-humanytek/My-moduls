To use this module, you need to:

#. Go to products and create one of type "Stockable".
#. Update quantities on hand to have stock of it.
#. Go to inventory dashboard and click on "Delivery Orders" card to create a new
   transfer.
#. Create a picking and select the product to do the transfer and save it.
#. Click on button *Change Location*, select in wizard the old location and
   new location.
