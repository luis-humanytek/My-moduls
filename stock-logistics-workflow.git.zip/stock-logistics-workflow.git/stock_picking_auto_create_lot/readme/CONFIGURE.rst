To configure this module, you need to:

#. Go to a *Inventory > Settings > Operation Types*.
#. Set 'auto create lot' option for this operation type.
